require("es6-promise").polyfill();
require("es5-shim");
require("fetch-ie8");

import Vue from 'vue'
import ElementUI from 'element-ui'
import 'reset.css/reset.css'
import 'element-ui/lib/theme-chalk/index.css'
import '~/assets/styles/index.less'
